import requests
import time
import datetime
import sqlite3
import json
from Setting import *
# while True:
#     req = requests.get('https://jwcasino.net/ostrichrun/result')
#     res = req.json()

#     ostrichrun_round = res["the"]

#     print(res["the"])

while True:
    res = requests.get("https://ntry.com/data/json/games/power_ladder/result.json?_="+str(time.time()).split(".")[0], headers={
        "Cookie": "PHPSESSID=8j6q0rl2vba819kgtk626a35r1; __cfruid=669704593becd435f21191986d753256d704b189-1651927909; open_chat_tab=lottery; best_family_master=fipn6to1b351cf3a2c9d3f8c5709865d536f8be4; top_family_master=5mn6v1yi31ae4a7d34a0c21d0d3fa950263412f1; best=1p6ns293ba5e586be1b9dea5d847d4b33d889e02; _ga=GA1.2.2010783188.1651927914; _gid=GA1.2.1418460696.1651927914",
        "Host": "ntry.com",
        "Referer": "http://ntry.com/scores/power_ladder/live.php",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.54 Safari/537.36",
        "X-Requested-With": "XMLHttpRequest",
    }).json()
    old_data = {}
    resp=res
    with open("./powerladder_temp.json", "r", encoding="utf8") as fp:
        old_data = json.loads(fp.read().strip())
    if( old_data == res ):
        pass
    else:
        with open("./powerladder_temp.json", "w", encoding="utf8") as fp:
#             fp.write(json.dumps(res))
#             data = {
#                 "username": f'{str(res["r"])}'"회차 파워사다리 결과",
#                 "content": f'''
# ```py
# [ 파워사다리 결과 ]

# 회차 : {str(res["r"])}

# {"좌" if res["s"] == "LEFT" else "우" } | {res["l"]} | {"홀" if res["o"] == "ODD" else "짝" }

# {res["date"]  + " - "+ str(res["r"]) + '회차'}
# ```
#                         '''}
#             requests.post(파워사다리, json=data)
            fp.write(json.dumps(res))
            fields = []
            fields.append({'name': '결과', 'value': f'{"좌" if res["s"] == "LEFT" else "우" } | {res["l"]} | {"홀" if res["o"] == "ODD" else "짝" }'})
            embed = { 'title': '파워사다리 결과', 'description': res["date"]  + " - "+ str(res["r"]) + '회차', 'fields': fields }
            requests.post(파워사다리, json={'username': str(res["r"])+"회차 파워사다리 결과", "embeds": [embed]})

        conn = sqlite3.connect('./database/database.db')
        c = conn.cursor()
        list_a = list(c.execute("SELECT * FROM users"))
        conn.close()
        for i in list_a:
            if(i[6] == None):
                print("none")
                continue
            print("found")


            conn = sqlite3.connect('./database/database.db')
            c = conn.cursor()
            if(i[18] == res["s"] or i[18] == res["l"] or i[18] == res["o"]):
                headers = {
                    "Authorization": f"Bot {봇토큰}"
                }
                js = {
                    "recipient_id": i[0]
                }
                headers = headers
                res = requests.post(url="https://discordapp.com/api/v9/users/@me/channels", json=js,
                                    headers=headers)
                data = res.json()
                dm_channel_id = data['id']
                embed = { 'title': f'적중', 'description': f'배팅 게임 : 파워사다리\n배팅 회차 : {resp["round"]}\n배팅 내역 : {i[18]}\n배팅 금액 : {i[19]}원\n─────────────\n적중 금액 : {round(i[19] * 0.98)}\n남은 금액 : {i[1] + round(i[19] * 1.98)}', 'color' : 0x00FF00}
                req = requests.post(f"https://discordapp.com/api/v9/channels/{dm_channel_id}/messages",
                headers=headers, json={
                'content' : f"<@{i[0]}> ", 'embed' : embed})
                c.execute("UPDATE users SET money = money + ? where id=?", (round(i[19] * 1.98), i[0],))
            else:
                headers = {
                    "Authorization": f"Bot {봇토큰}"
                }
                js = {
                    "recipient_id": i[0]
                }
                headers = headers
                res = requests.post(url="https://discordapp.com/api/v9/users/@me/channels", json=js,
                                    headers=headers)
                data = res.json()
                dm_channel_id = data['id']
                embed = { 'title': f'미적중', 'description': f'배팅 게임 : 파워사다리\n배팅 회차 : {resp["round"]}\n배팅 내역 : {i[18]}\n배팅 금액 : {i[19]}원\n─────────────\n적중 금액 : 0\n남은 금액 : {i[1]}', 'color' : 0xFF0000}
                req = requests.post(f"https://discordapp.com/api/v9/channels/{dm_channel_id}/messages",
                headers=headers, json={
                'content' : f"<@{i[0]}> ", 'embed' : embed})
            c.execute("UPDATE users SET powerladder_bet_pick = ? where id=?", ("", i[0],))
            c.execute("UPDATE users SET powerladder_bet_money = ? where id=?", (0, i[0],))
            conn.commit()
            conn.close()

    time.sleep(15)
