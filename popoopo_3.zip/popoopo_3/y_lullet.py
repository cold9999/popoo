import requests, time, random, json, sqlite3
from Setting import *

while True:
    try:
        res = requests.get("https://bepick.net/live/result/y_roulette?_="+str(time.time()).split(".")[0], headers={
            "Cookie": f"PHPSESSID=8j6q{random.randint(100,999)}2vba{random.randint(100,999)}kgtk626{random.randint(100,999)}r1; __cfruid=669704593{random.randint(100,999)}d435{random.randint(100,999)}191986d7{random.randint(100,999)}56d704b189-1{random.randint(100,999)}927909; open_chat_tab=lottery; best_family_master=fipn6{random.randint(100,999)}b351cf3a2c9d3f8c570{random.randint(100,999)}5d536f8be4; top_family_master=5mn6v1yi31ae4a7d34{random.randint(100,999)}21d0{random.randint(100,999)}a950263412f1; best=1p6ns293ba5e586be1b9dea5d84{random.randint(100,999)}b33d889e02; _ga=GA1.2.2010{random.randint(100,999)}188.1651927914; _gid=GA1.2.14{random.randint(100,999)}60696.16{random.randint(100,999)}27914",
            # "Host": "ntry.com",
            # "Referer": "http://ntry.com/scores/power_ladder/live.php",
            "User-Agent": f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4{random.randint(100,999)}.54 Safari/537.{random.randint(1,211)}",
            "X-Requested-With": "XMLHttpRequest",
        }).json()
        old_data = {}
        resp=res
        with open("./ylueet_temp.json", "r", encoding="utf8") as fp:
            old_data = json.loads(fp.read().strip())
        if( old_data == res ):
            pass
        else:
            with open("./ylueet_temp.json", "w", encoding="utf8") as fp:
    #             fp.write(json.dumps(res))
    #             data = {
    #                 "username": f'{res["round"]}'"회차 와이룰렛 결과",
    #                 "content": f'''
    # ```py
    # [ 와이룰렛 결과 ]

    # 회차 : {res["round"]}

    # 숫자
    # {res["op1"]}

    # 홀짝 옵언
    # { "짝" if int(res["fd3"]) % 2 == 0 else "홀" } / { "언더" if int(res["op1"]) < 13 else "오버" }
    # ```
    #                         '''}
    #             requests.post(와이룰렛, json=data)
                fp.write(json.dumps(res))
                fields = []
                fields.append({'name': '숫자', 'value': f'{res["op1"]}'})
                fields.append({'name': '색깔 홀짝 옵언', 'value': f'{"노랑" if int(res["fd1"]) % 2 == 0 else "빨강"} / { "짝" if int(res["fd3"]) % 2 == 0 else "홀" } / { "언더" if int(res["op1"]) < 13 else "오버" }'})
                embed = { 'title': '와이룰렛 결과', 'description': f'{res["round"]}회차', 'fields': fields }
                requests.post(와이룰렛, json={'username': f'{res["round"]}회차 와이룰렛 결과', "embeds": [embed]})
        
        # print(res)
                conn = sqlite3.connect('./database/database.db')
                c = conn.cursor()
                list_a = list(c.execute("SELECT * FROM users"))
                conn.close()
                yc="노랑" if int(res["fd1"]) % 2 == 0 else "빨강"

                yz = "짝" if int(res["fd3"]) % 2 == 0 else "홀"

                yo = "언더" if int(res["op1"]) < 13 else "오버"
            for i in list_a:
                    if(i[8] == None):
                        # print("none")
                        continue
                    
                    print("found")

                    conn = sqlite3.connect('./database/database.db')
                    c = conn.cursor()



                    print(f"{yc} {yz} {yo}")
                    print(i[8] == yc,i[8] == yz, i[8] == yo)

                    if(i[8] == yz or i[8] == yo or i[8] == yc):
                        headers = {
                            "Authorization": f"Bot {봇토큰}"
                        }
                        js = {
                            "recipient_id": i[0]
                        }
                        headers = headers
                        res = requests.post(url="https://discordapp.com/api/v9/users/@me/channels", json=js,
                                            headers=headers)
                        data = res.json()
                        dm_channel_id = data['id']
                        embed = { 'title': f'적중', 'description': f'배팅 게임 : 와이룰렛\n배팅 회차 : {resp["round"]}\n배팅 내역 : {i[8]}\n배팅 금액 : {i[9]}원\n─────────────\n적중 금액 : {round(i[9] * 0.98)}\n남은 금액 : {i[1] + round(i[9] * 1.98)}', 'color' : 0x00FF00}
                        req = requests.post(f"https://discordapp.com/api/v9/channels/{dm_channel_id}/messages",
                        headers=headers, json={
                        'content' : f"<@{i[0]}> ", 'embed' : embed})
                        c.execute("UPDATE users SET money = money + ? where id=?", (round(i[9] * 1.98), i[0],))
                        f = open(f"./bet_log/{i[0]}.txt", "a", encoding="utf-8-sig")
                        f.write(
                            f'''                
    배팅게임 : 와이룰렛
    배팅회차 : {resp["round"]}
    배팅내역 : {i[8]}
    배팅금 : {i[9]}
    적중 / 미적중 : 적중
    적중 금액 : {round(i[9] * 0.98)}
    남은 금액 : {i[1] + round(i[9] * 1.98)}
    ======================
    ''')
                        f.close()
                    else:
                        headers = {
                            "Authorization": f"Bot {봇토큰}"
                        }
                        js = {
                            "recipient_id": i[0]
                        }
                        headers = headers
                        res = requests.post(url="https://discordapp.com/api/v9/users/@me/channels", json=js,
                                            headers=headers)
                        data = res.json()
                        dm_channel_id = data['id']
                        embed = { 'title': f'미적중', 'description': f'배팅 게임 : 와이룰렛\n배팅 회차 : {resp["round"]}\n배팅 내역 : {i[8]}\n배팅 금액 : {i[9]}원\n─────────────\n적중 금액 : 0\n남은 금액 : {i[1]}', 'color' : 0xFF0000}
                        req = requests.post(f"https://discordapp.com/api/v9/channels/{dm_channel_id}/messages",
                        headers=headers, json={
                        'content' : f"<@{i[0]}> ", 'embed' : embed})
                        f = open(f"./bet_log/{i[0]}.txt", "a", encoding="utf-8-sig")
                        f.write(
                            f'''                
    배팅게임 : 와이룰렛
    배팅회차 : {resp["round"]}
    배팅내역 : {i[8]}
    배팅금 : {i[9]}
    적중 / 미적중 : 미적중
    남은 금액 : {i[1]}
    ======================
    ''')
                        f.close()

                    c.execute("UPDATE users SET wllet_bet_pick = ? where id=?", (None, i[0],))
                    c.execute("UPDATE users SET wllet_bet_money = ? where id=?", (None, i[0],))
                    conn.commit()
                    conn.close()

        time.sleep(5)
    except:
        pass