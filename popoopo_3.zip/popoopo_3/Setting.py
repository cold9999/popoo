# 웹훅 적으세여

타조게임="https://discordapp.com/api/webhooks/1096418177598099509/J1DmzR-WfcKTurs-_4r1jJ3TTnUZejevPd8HdVXlwk8Agtv-A6jR5C1MGy1fwQiCHuCw" # 타조 결과값 웹훅
와이룰렛="https://discordapp.com/api/webhooks/1096418177598099509/J1DmzR-WfcKTurs-_4r1jJ3TTnUZejevPd8HdVXlwk8Agtv-A6jR5C1MGy1fwQiCHuCw" # 와이룰렛 결과값 웹훅
와이빙고="https://discord.com/api/webhooks/1084311286478807111/FKgU4TyOqz4q1EjhNbSnNR1ax6pKwHW6eSlLzRUDRFGUeZV0UKWSruPS3o_W0yPNpEqU" # 와이빙고 결과값 웹훅
보글볼="https://discord.com/api/webhooks/1078671992414294027/TIJJZBUPtOnBhqfYthMHuts_FcByqIaX7LzxNHmj7cRRudhk3Tkhbkt4WmrXnSOn40zN" # 보글볼 결과값 웹훅
파워볼="https://discord.com/api/webhooks/1081807633624870943/1cRwtBQFcp-YHL9N3_XEBU9b8SGVlBZTJf36FBAJLriDwLZ-82vZUZy65eMf4pcaIPnf" # 파워볼 결과값 웹훅
보글사다리='https://discord.com/api/webhooks/1081807756752859206/aAaaBLyb5x-BHf9YDW3XKJZ8NW3YrHjxESrHYM3kgBSqhQ9y9Ux6_H9y12SWGOoretoc'
이오스1분="https://discord.com/api/webhooks/1078672122152497242/Q3Sm-J7O0nf4pTPdOMy6Ahh0LFlsG8wQWK5WA3YJyLeEqhFbWlJl5MtMTt9lpvbDv6Eq" # 이오스1분 결과값 웹훅
이오스2분="https://discord.com/api/webhooks/1081914871211372614/anqBOQsqJIHXf3ImplS0gRnIOHWEIPb3bqBLRuIT0UC6I_RgF4SWGl19AyoRf30JzYeV" # 이오스2분 결과값 웹훅
이오스3분="https://discordapp.com/api/webhooks/1096418177598099509/J1DmzR-WfcKTurs-_4r1jJ3TTnUZejevPd8HdVXlwk8Agtv-A6jR5C1MGy1fwQiCHuCw" # 이오스3분 결과값 웹훅
이오스4분="https://discordapp.com/api/webhooks/1096418177598099509/J1DmzR-WfcKTurs-_4r1jJ3TTnUZejevPd8HdVXlwk8Agtv-A6jR5C1MGy1fwQiCHuCw" # 이오스4분 결과값 웹훅
비트코인사다리="https://discord.com/api/webhooks/1081807707121668096/dTKrAuWKotB7qsv4Oruid1hPRJgfidguT3LSwseBEG_2dXQERY5EqnGRfT-O-sm13t4j"
이오스5분="https://discord.com/api/webhooks/1078672503972564992/7gkZptdS3Vj1f6m4cYdksPZdrJtiEM1DQs1VLsnohFooUMmJS5abrfC8IookBLI-jy4i" # 이오스5분 결과값 웹훅
천사와악마="https://discord.com/api/webhooks/1081911528078442556/Qk4OCfDYYn2UXPQnT8Ww_748P0UvOkzq-NEy1Ml4mxb8r-08wiAKVOjyLBPUZmQZobj0" # 마리오 결과값 웹훅 
힘쎈공="https://discord.com/api/webhooks/1082682660687712296/yX7V7QnDC2rB3KCUWwfoavVUrV_3A9Wa3UrgyhukHkSCrWqCUli0JZHiD278Zc4DyCQd" # 힘쎈거ㅇ 결과값 웹훅
힘쎈사다리="https://discord.com/api/webhooks/1082682848437346365/4OLTTdprhdhgsi9FJHCQqRb4srXbKp2XHlYjruHml5qc36HCbgKrPwflFyrOsMoPXmkh" # 힘센사다리 결과값 웹훅 
마리오="https://discord.com/api/webhooks/1083981180606615632/9izMhLxM6OIYml6JHqETVEd8cwU_AdV7KGL_blo9eHfdgwotrQ7eobG2btJzFY5c1M8f" # 동행키노 결과값 웹훅 
두옌하바카라="https://discord.com/api/webhooks/1084007632433577994/jkDM3KNbHmFXUjs9fKBbuIDqYe6uLYk_G4wbC7UW8JCdQgtM4eGKzMWfgWIAkUvdcvhU" # 동행키노 결과값 웹훅
게임로그웹훅="https://discord.com/api/webhooks/1080134963111927818/5q75CQ3_E5aFfOuXxMjw4U9MysRqLWQIEPhSiWGDAVZHPfWJQt_jF8XKp5FKsCo0iJDu"
파워사다리="https://discordapp.com/api/webhooks/1096418177598099509/J1DmzR-WfcKTurs-_4r1jJ3TTnUZejevPd8HdVXlwk8Agtv-A6jR5C1MGy1fwQiCHuCw"

충전채널=1148263460820492298 # 충전버튼누르는채널 id
요청채널=1148261461039263814 # 계좌 충전 승인하는 관리자채널 id

관리자=[655349356886622222,790413552413573120,662477199529607190,1032267591475019797,1124358354731540580] #관리자 id
서버이름="Haku Land"
봇디엠로그=996774873722536085 #봇 디엠로그 id
입출금로그=1148263415664611409 # 입출금로그 채널 id
입출금로그웹훅="https://discord.com/api/webhooks/1149267764704452659/mbNBjK0jvwS7Il52uHYDB7-b6gPDU8TB6RFSeCq6PIDuEJyQVdk4QT0i_U9Rckb-77Vh" # 입출금로그 채널 웹훅
계좌번호="토스 1908-8941-6572 김범석"#"9003253587970 새마을 김민재" # 은행명 계좌번호 예금주
tossbanks = "https://toss.me/haku" # 토스 테스트
btcwallet="bc1qfzwmlutu9z08mktaucluefv75rga7jqlavdhqs"
ltcwallet="Lbfgu6i8CTZDHUrQymrsvrAKnwCr2b2QZQ"
ethwallet="0x56810ae47432E8F821206b3fC44c9b8563f55Ba0"
#홀짝 ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
배팅내역=1148978509558063244 # 채널 id 수정
홀짝채널=1148978364175101992 # 채널 id 수정
홀짝회차=1148978509558063244 # 채널 id 수정
유출픽=996774873722536085 # 채널 id 수정
#바카라 ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
바카라채널=1147898418254073866 # 채널 id 수정
바카라유출픽=996774873722536085 # 채널 id 수정
바카라회차=1147898466727628891 # 채널 id 수정
바카라배팅내역=1147898466727628891 # 채널 id 수정
코인채널=996774873722536085 # 채널 id
# 용호 ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
용호채널=1148619961883967489
용호유출픽=996774873722536085
용호회차=1148620291036168192
용호배팅내역=1148620291036168192
# 경마 ㅡㅡㅡㅡㅡ
경마채널=996774873722536085
경마회차=996774873722536085
경마배팅내역=996774873722536085
# 룰렛 ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
룰렛2채널=996774873722536085
룰렛유출픽=996774873722536085
룰렛회차=996774873722536085
룰렛배팅내역=996774873722536085
# 하이로우
하이로우채널=1148978800328196176
하이로우배팅내역=1148978874693210122
하이로우회차=1148978874693210122
하이로우유출픽=996774873722536085
라바카라채널=1148978632916750396
라바카라회차=1148978767398711410
라바카라유출픽=996774873722536085
라바카라배팅내역=1148978767398711410
파워볼채널=996774873722536085
봇토큰="NzgzMjMyNTM1MTQzNTE0MTEy.GGzW0h.u1sF8HGl9CuYQhFb9t0odzpo-enTBOsWHiOCRQ"
